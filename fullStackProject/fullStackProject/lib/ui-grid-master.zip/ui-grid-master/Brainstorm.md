Moved to https://docs.google.com/document/d/1fk7EwwJUGq3MTXaE6vp29rA4sXgzp5DA_rn_ERcPIz8/edit?usp=sharing
(Please sign-in to google so that we know who changed what for followup questions)