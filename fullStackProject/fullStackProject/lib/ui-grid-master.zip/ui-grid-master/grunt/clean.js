module.exports =
  // Clean the temp directory
  ['.tmp', '<%= dist %>', 'docs', 'coverage']
;
